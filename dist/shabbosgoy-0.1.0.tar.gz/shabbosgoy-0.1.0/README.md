# ShabbosGoy

ShabbosGoy is an agentic AI sysadmin tool that executes commands and scripts in a Linux terminal environment.

## Installation

```bash
pip install shabbosgoy
```

## Usage

```bash
shabbosgoy [options]
```

## Features

- Executes commands and scripts in a Linux terminal environment
- Maintains working memory across steps
- Solves complex multi-step problems

## License

This project is licensed under the MIT License - see the LICENSE file for details.
